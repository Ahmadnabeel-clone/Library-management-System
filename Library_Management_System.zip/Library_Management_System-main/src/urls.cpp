// role : Student , Librarian, Professor
#define DB_USER "../db/user.txt" // 
#define DB_COOKIE "../db/cookie.txt" //  sno name id password role
#define DB_BOOK "../db/book.txt"
#define DB_USER_BOOK "../db/user_book.txt"
