# Library_Management_System


Library Management System Model in C++

main.cpp : contains the main code to run the program
model.h : contains the required classes
urls.cpp : contains the location of databases stored
views.cpp : contains the functions to execute function present in classes
user.txt : stores the list of users and their passwords Format: sno name id password role

Librarian can add, update, delete a user or a book; can see the list of available user or books; can see which book is issued to which user and which user has which books issued; can clear the fine of a respective user corresponding to a particular book.

Student can see all the available books, see the list of books s/he has issued along with his/her current fine, can check if he/she can issue a particular book or not, and can issue a book.
